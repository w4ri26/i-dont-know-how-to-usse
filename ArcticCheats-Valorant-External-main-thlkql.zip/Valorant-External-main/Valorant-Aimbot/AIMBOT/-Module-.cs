﻿using System;
using Costura;

// Toksen: 0x02000001 RID: 1
internal class <Module>
{
	// Token: 0x06000001 RID: 1 RVA: 0x00002050 File Offset: 0x00000250
	static <Module>()
	{
		AssemblyLoader.Attach();
	}
}
internal class <Module>
{
	// Token: 0x06000001 RID: 1 RVA: 0x00002050 File Offset: 0x00000250
	static <Module>()
	{
		AssemblyLoader.Attach();
	}
}
